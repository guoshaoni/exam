import Vue from 'vue'
import Router from 'vue-router'
import VueResource from 'vue-resource'
import login from '../components/login/login.vue'
import manager from '../components/manager/manager.vue'

Vue.use(Router)
Vue.use(VueResource)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'login',
      component: login
    },
    {
      path: '/manager',
      name: 'manager',
      component: manager,
      children:[
          {path:'/managerDir',name:'managerDir',component:managerDir}
      ]
    }
  ]
})
